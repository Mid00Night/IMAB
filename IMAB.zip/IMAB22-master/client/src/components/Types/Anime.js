import React from "react";

const AnimeClothe = {};
